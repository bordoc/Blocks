﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHarkavyi44578
{
    public partial class Form2 : Form
    {
        public int x = 10;
        public int y = 10;
        public Form2()
        {
            InitializeComponent();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = trackBar1.Value.ToString();
            x = trackBar1.Value;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                x = Convert.ToInt32(textBox1.Text);
                trackBar1.Value = Convert.ToInt32(textBox1.Text);
            }
            catch { }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                y = Convert.ToInt32(textBox2.Text);
                trackBar2.Value = Convert.ToInt32(textBox2.Text);
            }
            catch { }
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            textBox2.Text = trackBar2.Value.ToString();
            y = trackBar2.Value;
        }

        private void OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
